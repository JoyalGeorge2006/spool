package com.music.bitchord.data

import com.music.bitchord.data.DebugLog as Log
import com.music.bitchord.data.innertube.Innertube
import com.music.bitchord.data.innertube.InnertubeParser
import com.music.bitchord.data.model.Account
import com.music.bitchord.data.model.AccountChannel
import com.music.bitchord.data.model.isExactArtistMatch
import com.music.bitchord.data.model.normalizedArtistName
import com.music.bitchord.data.model.ArtistPage
import com.music.bitchord.data.model.BrowseType
import com.music.bitchord.data.model.HomeFeed
import com.music.bitchord.data.model.HomeShelf
import com.music.bitchord.data.model.LibraryPage
import com.music.bitchord.data.model.LibraryState
import com.music.bitchord.data.model.LikeStatus
import com.music.bitchord.data.model.MoodGenreSection
import com.music.bitchord.data.model.playlistMoves
import com.music.bitchord.data.model.PlaylistPrivacy
import com.music.bitchord.data.model.SearchFilter
import com.music.bitchord.data.model.SearchResult
import com.music.bitchord.data.model.ShelfItem
import com.music.bitchord.data.model.Song
import com.music.bitchord.data.model.SongMenu
import com.music.bitchord.data.model.UserPlaylist
import com.music.bitchord.data.model.WatchTarget
import com.music.bitchord.data.sources.TrackMatcher
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.JsonObject
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Suspend API over Innertube. Every call returns a Result so the UI can show a real error. */
object YtMusicRepository {

    private const val TAG = "BitChord"
    private val moodGenreShelfCache = ConcurrentHashMap<String, List<HomeShelf>>()
    /**
     * The core personalised feed. It stays deliberately independent from the
     * optional shelves below: callers can paint this response immediately,
     * rather than making the Play page wait for every supplementary endpoint.
     *
     * FEmusic_home's own continuation token comes back, for [moreHome] —
     * signed in, it keeps paging into mood mixes and more personalised
     * shelves the same way the official app does as you scroll; signed out
     * it's empty and there's nothing more to fetch.
     */
    suspend fun home(): Result<HomeFeed> = call("home") {
        val home = Innertube.browse("FEmusic_home")
        HomeFeed(InnertubeParser.parseHome(home), InnertubeParser.continuationToken(home))
    }

    /** Recently played is rendered independently, at the top of the Play page. */
    suspend fun homeRecentlyPlayed(): Result<HomeShelf?> = call("home:recent") { recentlyPlayed() }

    /** Extra Play shelves are independently fetchable so each can appear as soon as it arrives. */
    suspend fun homeSupplement(browseId: String): Result<List<HomeShelf>> = call("home:$browseId") {
        shelvesOf(browseId)
    }

    val HOME_SUPPLEMENT_BROWSE_IDS = listOf(
        "FEmusic_new_releases",
        "FEmusic_explore",
    )

    /**
     * More Home shelves past [home]'s first page, following FEmusic_home's
     * own continuation — the lever the official app pulls as you scroll
     * rather than a fixed one-shot page. "Recently played" and
     * FEmusic_new_releases are one-shot and don't participate.
     */
    suspend fun moreHome(token: String): Result<HomeFeed> = call("home:more") {
        val response = Innertube.browseContinuation(token)
        HomeFeed(
            shelves = InnertubeParser.parseHomeContinuation(response),
            continuation = InnertubeParser.continuationToken(response),
        )
    }

    /**
     * The lead shelf: the account's listening history, newest first.
     *
     * YouTube's home already carries a "Listen again", but it ranks by how
     * *often* something has been played rather than how recently — so it keeps
     * leading with last month's favourites for days after a change of mood,
     * which reads as the feed being broken. The history feed reflects a play
     * the moment it's registered, so it's what the top of the page is built
     * from. YouTube's own shelf stays below, where its ranking is a feature.
     *
     * Signed-in only; there is no history to read as a guest.
     */
    private suspend fun recentlyPlayed(): HomeShelf? {
        val ytSongs = if (Innertube.cookie != null) {
            runCatching { fetchHistory() }.getOrDefault(emptyList())
        } else {
            emptyList()
        }

        val allSongs = ytSongs.distinctBy { it.videoId }.take(RECENT_LIMIT)
        if (allSongs.isEmpty()) return null
        return HomeShelf(
            title = RECENT_TITLE,
            items = allSongs.map {
                ShelfItem(
                    title = it.title,
                    subtitle = it.artist,
                    thumbnailUrl = it.thumbnailUrl,
                    videoId = it.videoId,
                    browseId = null,
                )
            },
        )
    }

    /**
     * The raw fetch behind both [recentlyPlayed] and [history]: the account's
     * listening history, newest first, one row per play collapsed to one row
     * per track.
     *
     * A track played three times today is three rows in the feed — what that
     * dedupe costs is the times, which is fine for "what you have been
     * listening to" but would matter for a log. YouTube's own page groups them
     * under Today and Yesterday headings that the shelf parser doesn't carry
     * through either.
     */
    private suspend fun fetchHistory(): List<Song> = historyLock.withLock {
        val identity = Innertube.listenerGeneration
        // Recents and Top Picks both want the history the moment Home opens;
        // whichever asks second waits for the first and shares its answer
        // instead of sending the same request again.
        historyMemo?.takeIf { it.identity == identity && System.currentTimeMillis() - it.at < HISTORY_SHARE_MS }
            ?.let { return@withLock it.songs }
        InnertubeParser.collectSongsDeep(Innertube.browse(HISTORY)).distinctBy { it.videoId }
            .let { songs ->
                // Discard in-flight results across account/channel changes, including A -> B -> A.
                check(identity == Innertube.listenerGeneration) { "Listener changed during history load" }
                historyMemo = HistoryMemo(identity, System.currentTimeMillis(), songs)
                songs
            }
    }

    private val historyLock = Mutex()

    /** Two requests for the history this close together are the same request. */
    private const val HISTORY_SHARE_MS = 5_000L

    /**
     * The account's listening history, in the order YouTube Music keeps it.
     *
     * The same feed [recentlyPlayed] reads, without the truncation: that one is
     * a shelf on the home page and stops at [RECENT_LIMIT] so it stays a shelf,
     * whereas this is the page you open when twenty is not enough.
     */
    suspend fun history(): Result<List<Song>> = call("history") { fetchHistory() }

    /** Account listening history for the Recents feed. */
    suspend fun recents(): Result<List<Song>> = call("recents") {
        if (Innertube.cookie != null) {
            val history = runCatching { fetchHistory() }.getOrDefault(emptyList())
            if (history.isNotEmpty()) return@call history
        }
        emptyList()
    }

    /** Removes a track from the account's listening history via its feedback token. */
    suspend fun removeFromHistory(token: String): Result<Unit> = call("removeFromHistory") {
        Innertube.sendFeedback(token)
    }

    /** Invalidates the in-memory history cache so the next load fetches fresh data. */
    fun invalidateHistoryCache() {
        historyMemo = null
    }

    /**
     * Recommended discovery tracks for Quick Picks, strictly excluding listening history and recents.
     */
    suspend fun quickPicks(excludeSongIds: Set<String> = emptySet()): Result<List<Song>> = call("quickPicks") {
        val homeRaw = runCatching { Innertube.browse("FEmusic_home") }.getOrNull()
        val shelves = if (homeRaw != null) InnertubeParser.parseHome(homeRaw) else emptyList()

        // 1. Direct "Quick picks" or "Mix" or "Recommendations" shelf
        val qpShelf = shelves.firstOrNull {
            it.title.contains("quick", ignoreCase = true) ||
                it.title.contains("pick", ignoreCase = true) ||
                it.title.contains("mix", ignoreCase = true) ||
                it.title.contains("recommend", ignoreCase = true)
        }
        val qpSongs = qpShelf?.items?.mapNotNull { item ->
            item.videoId?.takeUnless { it in excludeSongIds }?.let { vid ->
                Song(
                    videoId = vid,
                    title = item.title,
                    artist = InnertubeParser.artistFromSubtitle(item.subtitle),
                    thumbnailUrl = item.thumbnailUrl,
                )
            }
        }.orEmpty()
        if (qpSongs.isNotEmpty()) return@call qpSongs

        // 2. All shelves on Home (excluding shelves mentioning recent/history, and skipping top shelf if multiple exist)
        val candidateShelves = if (shelves.size > 1) {
            shelves.drop(1).filterNot {
                it.title.contains("recent", ignoreCase = true) ||
                    it.title.contains("history", ignoreCase = true) ||
                    it.title.contains("listen again", ignoreCase = true)
            }
        } else shelves

        val homeShelfSongs = candidateShelves.flatMap { shelf ->
            shelf.items.mapNotNull { item ->
                item.videoId?.takeUnless { it in excludeSongIds }?.let { vid ->
                    Song(
                        videoId = vid,
                        title = item.title,
                        artist = InnertubeParser.artistFromSubtitle(item.subtitle),
                        thumbnailUrl = item.thumbnailUrl,
                    )
                }
            }
        }.distinctBy { it.videoId }

        if (homeShelfSongs.isNotEmpty()) return@call homeShelfSongs

        // 3. Any shelf items on Home that have videoId
        val allHomeTrackSongs = shelves.flatMap { shelf ->
            shelf.items.mapNotNull { item ->
                item.videoId?.let { vid ->
                    Song(
                        videoId = vid,
                        title = item.title,
                        artist = InnertubeParser.artistFromSubtitle(item.subtitle),
                        thumbnailUrl = item.thumbnailUrl,
                    )
                }
            }
        }.distinctBy { it.videoId }

        val uniqueAllHome = allHomeTrackSongs.filterNot { it.videoId in excludeSongIds }
        if (uniqueAllHome.isNotEmpty()) return@call uniqueAllHome

        // 4. Explore / New releases
        val explore = runCatching { shelvesOf("FEmusic_new_releases") }.getOrDefault(emptyList())
        val exploreSongs = explore.flatMap { shelf ->
            shelf.items.mapNotNull { item ->
                item.videoId?.takeUnless { it in excludeSongIds }?.let { vid ->
                    Song(
                        videoId = vid,
                        title = item.title,
                        artist = InnertubeParser.artistFromSubtitle(item.subtitle),
                        thumbnailUrl = item.thumbnailUrl,
                    )
                }
            }
        }.distinctBy { it.videoId }

        if (exploreSongs.isNotEmpty()) return@call exploreSongs

        // 5. Fallback if everything was filtered out
        allHomeTrackSongs.ifEmpty { exploreSongs }
    }

    private const val HISTORY = "FEmusic_history"
    const val RECENT_TITLE = "Recents"

    /** Enough to scroll through, short of turning the shelf into the history page. */
    private const val RECENT_LIMIT = 20

    private suspend fun shelvesOf(browseId: String): List<HomeShelf> =
        InnertubeParser.parseHome(Innertube.browse(browseId))

    /** The server-defined mood and genre categories used by Explore. */
    suspend fun moodAndGenres(): Result<List<MoodGenreSection>> = call("moods-and-genres") {
        InnertubeParser.parseMoodAndGenres(Innertube.browse("FEmusic_moods_and_genres"))
    }

    /**
     * The playlist shelves behind one mood/genre category. This result also
     * supplies its tile artwork, so caching it avoids a second request when a
     * user taps a category whose cover has already appeared.
     */
    suspend fun moodGenreShelves(browseId: String, params: String?): Result<List<HomeShelf>> {
        val key = "$browseId:${params.orEmpty()}"
        moodGenreShelfCache[key]?.let { return Result.success(it) }
        return call("mood-genre:$browseId") {
            InnertubeParser.parseHome(Innertube.browse(browseId, params))
        }.also { result -> result.getOrNull()?.let { moodGenreShelfCache.putIfAbsent(key, it) } }
    }

    /** A category card borrows the first real cover from the playlists it opens. */
    suspend fun moodGenreArtwork(browseId: String, params: String?): Result<String?> =
        moodGenreShelves(browseId, params).map { shelves ->
            shelves.asSequence().flatMap { it.items.asSequence() }
                .mapNotNull(ShelfItem::thumbnailUrl)
                .firstOrNull()
        }

    /** One page of a search response, with the token for its next page if present. */
    data class SearchPage(
        val rows: List<SearchResult>,
        val continuation: String?,
    )

    /**
     * Fetches only the first search page. Publishing it immediately keeps the
     * search responsive; the UI asks [searchContinuation] for later pages as
     * the listener reaches the end of the list.
     */
    suspend fun searchPage(query: String, filter: SearchFilter, anonymous: Boolean = true): Result<SearchPage> =
        call("search:${filter.name}") {
            InnertubeParser.parseSearchPage(
                Innertube.search(query, filter.params, anonymous),
                includeVideos = filter == SearchFilter.VIDEOS,
            ).let { page ->
                SearchPage(page.rows.distinctBy { it.identityKey() }, page.continuation)
            }
        }

    /** Fetches the next page of a search only when the result list needs it. */
    suspend fun searchContinuation(token: String, filter: SearchFilter): Result<SearchPage> = call("search:continuation") {
        InnertubeParser.parseSearchPage(
            Innertube.searchContinuation(token),
            includeVideos = filter == SearchFilter.VIDEOS,
        ).let { page ->
            SearchPage(page.rows.distinctBy { it.identityKey() }, page.continuation)
        }
    }

    /**
     * Compatibility helper for callers that need candidates but not a scrolling
     * result screen. Those callers need the first, most relevant page only.
     */
    suspend fun search(query: String, filter: SearchFilter): Result<List<SearchResult>> =
        searchPage(query, filter).map { it.rows }

    private fun SearchResult.identityKey(): String = when (this) {
        is SearchResult.TopTrack -> "v:${song.videoId}"
        is SearchResult.Track -> "v:${song.videoId}"
        is SearchResult.Browse -> "b:${item.browseId}"
    }

    /**
     * What YouTube Music would suggest completing [input] to, for the search
     * field's typeahead. Unfiltered on purpose: a suggestion is a query, and
     * which tab it is then run against is the user's to pick afterwards.
     */
    suspend fun searchSuggestions(input: String): Result<List<String>> =
        call("suggest") {
            InnertubeParser.parseSearchSuggestions(Innertube.searchSuggestions(input))
        }

    /**
     * Live media results for the typeahead phase — a lightweight search that
     * returns tracks, artists, and albums so the dropdown can show playable
     * cards alongside text completions. Uses the ALL filter to get mixed
     * results quickly; callers may want to limit how many they display.
     *
     * Deliberately unauthenticated: [Innertube.searchTypeahead] strips the
     * session cookie so YouTube Music does not log each debounced keystroke
     * to the account's server-side search history. Confirmed searches (Enter /
     * IME Search / tapping a suggestion) still use the normal authenticated
     * [searchPage] path and are recorded properly.
     */
    suspend fun searchTypeahead(input: String): Result<SearchPage> =
        call("typeahead:$input") {
            InnertubeParser.parseSearchPage(
                Innertube.searchTypeahead(input),
                includeVideos = false,
            ).let { page ->
                SearchPage(page.rows.distinctBy { it.identityKey() }, page.continuation)
            }
        }

    /** Legacy callers preserve the exact recording without catalogue or counterpart requests. */
    @Deprecated("Audio-only playback preserves the original upload")
    suspend fun resolveAudio(song: Song): Song = song

    /** Actual audio fallback. Failed requests cannot establish no audio match. */
    internal suspend fun findAudioVersionBySearch(
        song: Song,
        fetch: suspend (String) -> Result<List<Song>>,
    ): Song? {
        val target = TrackMatcher.targetOf(song)
        var failure: Throwable? = null
        for (query in TrackMatcher.queries(target)) {
            val result = fetch(query)
            result.exceptionOrNull()?.let {
                if (it is CancellationException) throw it
                failure = it
            }
            val candidates = result.getOrNull().orEmpty()
            TrackMatcher.best(candidates, target)?.let { return it }
            // Music-video runtime can include intros/outros absent from the release.
            TrackMatcher.bestOfficialAudioForVideo(candidates, target)?.let { return it }
        }
        failure?.let { throw it }
        Log.w(TAG, "audio switch: no official song match for '${song.title}' by '${song.artist}'")
        return null
    }

    /** Legacy counterpart lookup is retired and cannot trigger a network request. */
    @Deprecated("Watchable video and counterpart switching have been removed")
    suspend fun resolveVideo(song: Song): Song? = null

    /** Actual fallback search path, injectable only to test provider outcomes. */
    internal suspend fun findVideoVersionBySearch(
        song: Song,
        fetch: suspend (String) -> Result<List<Song>>,
    ): Song? {
        val target = TrackMatcher.targetOf(song)
        var failure: Throwable? = null
        for (query in TrackMatcher.queries(target)) {
            val result = fetch(query)
            result.exceptionOrNull()?.let {
                if (it is CancellationException) throw it
                failure = it
            }
            val candidates = result.getOrNull().orEmpty()
            TrackMatcher.best(candidates, target)?.let { return it }
        }
        // A partially or fully failed lookup cannot establish absence.
        failure?.let { throw it }
        Log.w(TAG, "video switch: no video match for '${song.title}' by '${song.artist}'")
        return null
    }

    /** Signed-in profile for the settings header. Null when signed out. */
    suspend fun account(): Result<Account> = call("account") {
        InnertubeParser.parseAccount(Innertube.accountMenu())
            ?: error("No account details")
    }

    /**
     * The channels this login can act as — its own, plus any brand channels.
     *
     * Two endpoints are asked in turn because either can come back with an
     * envelope holding no `accountItem` at all, and the two do not fail
     * together: `accounts_list` is the first-party route and the switcher is
     * what youtube.com's own avatar menu uses. An empty list from the first is
     * not an answer, it is a shape this parser didn't recognise, so it is
     * treated the same as a failure and the other route is tried.
     */
    suspend fun accountChannels(): Result<List<AccountChannel>> = call("channels") {
        val viaInnertube = runCatching {
            InnertubeParser.parseAccountChannels(Innertube.accountsList())
        }.onFailure { Log.w(TAG, "accounts_list unavailable: ${it.message}") }
            .getOrNull()
            .orEmpty()
        if (viaInnertube.isNotEmpty()) return@call viaInnertube
        InnertubeParser.parseAccountChannels(Innertube.accountSwitcher())
    }

    /**
     * [account] for a login that is not saved yet. Uses only [credentials]; it
     * neither reads nor changes the active session, and never retries through
     * the shared refresh path.
     */
    suspend fun stagedAccount(credentials: Innertube.StagedCredentials): Result<Account> =
        withContext(Dispatchers.IO) {
            runCatching {
                InnertubeParser.parseAccount(Innertube.stagedAccountMenu(credentials))
                    ?: error("No account details")
            }.onFailure { if (it is CancellationException) throw it }
        }

    /** [accountChannels] for a login that is not saved yet; same isolation as [stagedAccount]. */
    suspend fun stagedChannels(credentials: Innertube.StagedCredentials): Result<List<AccountChannel>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val viaInnertube = runCatching {
                    InnertubeParser.parseAccountChannels(Innertube.stagedAccountsList(credentials))
                }.onFailure { if (it is CancellationException) throw it }.getOrNull().orEmpty()
                viaInnertube.ifEmpty {
                    InnertubeParser.parseAccountChannels(Innertube.stagedAccountSwitcher(credentials))
                }
            }.onFailure { if (it is CancellationException) throw it }
        }

    /**
     * The whole library in one shot — requires a signed-in session.
     *
     * YouTube Music has no single "my library" feed: Liked Music is the `LM`
     * auto-playlist, the songs added to the library are a separate feed, and
     * every saved collection has its own browse id. They're fetched in
     * parallel and a feed that fails or is simply empty (a fresh account has
     * no saved albums) is dropped rather than failing the whole page.
     */
    suspend fun library(): Result<LibraryPage> {
        val generation = Innertube.listenerGeneration
        return call("library") {
            coroutineScope {
                // Liked Music is read one page at a time. The first page is what
                // the Library tab needs to fill and is published straight away;
                // the rest of the collection is synced into LikeState in the
                // background, so a liked track past the first page still reads as
                // liked without holding this page open behind the whole list —
                // see [syncLikedMusic] and MainViewModel's fetchLibrary.
                val liked = async { browseSongs(LIKED_MUSIC).getOrNull() }
                val added = async { runCatching { songsPaged(LIBRARY_SONGS) }.getOrDefault(emptyList()) }
                val shelves = LIBRARY_FEEDS
                    .map { (title, browseId) ->
                        async {
                            HomeShelf(title, runCatching { libraryItemsPaged(browseId) }.getOrDefault(emptyList()))
                        }
                    }
                    .awaitAll()
                    .filter { it.items.isNotEmpty() }

                val likedPage = liked.await()
                val likedSongs = likedPage?.songs.orEmpty()
                val likedIds = likedSongs.mapTo(HashSet()) { it.videoId }
                val addedSongs = added.await()
                check(Innertube.ifCurrentListener(generation) { LikeState.seedLiked(likedIds) }) {
                    "Listener changed while loading library"
                }
                LibraryPage(
                    likedSongs = likedSongs,
                    // Thumbs-up'd tracks are also in the library feed; only what
                    // the "Liked Music" list doesn't already cover is worth a
                    // second section.
                    librarySongs = addedSongs.filterNot { it.videoId in likedIds },
                    shelves = shelves,
                    likedContinuation = likedPage?.continuation,
                )
            }
        }
    }

    /**
     * Finishes syncing the liked collection into [LikeState], following
     * [firstToken] page by page until the feed runs dry.
     *
     * Unlike [songsPaged]'s [MAX_PAGES], this is deliberately unbounded: it
     * seeds only video ids (not the full [Song]s), so syncing a long Liked
     * Music library stays cheap, and stopping at a page cap would leave every
     * liked track past that page reading as "not liked" — the very symptom
     * #219 reported.
     *
     * [loadNext] is injectable so the pagination loop is unit-testable; the
     * default reads through [moreSongs] and stops on a failed page rather
     * than surfacing an error for a background sync. Cancellation is
     * cooperative and the caller (a ViewModel scope in the app) decides when
     * this outlives its usefulness.
     *
     * Guards only against a token repeating — a page pointing back at one
     * already read, which would otherwise spin forever — rather than a page
     * count, since a genuinely large library is exactly what this exists to
     * keep reading.
     */
    suspend fun syncLikedMusic(
        firstToken: String?,
        loadNext: suspend (String) -> SongPage? = { moreSongs(it).getOrNull() },
    ) {
        if (firstToken == null) return
        val generation = Innertube.listenerGeneration
        val seen = HashSet<String>()
        var next: String? = firstToken
        while (next != null && seen.add(next)) {
            if (generation != Innertube.listenerGeneration) return
            val page = loadNext(next) ?: return
            if (!Innertube.ifCurrentListener(generation) {
                LikeState.seedLiked(page.songs.mapTo(HashSet()) { it.videoId })
            }) return
            next = page.continuation
        }
    }

    /**
     * What YouTube Music would play on after [videoId]. Feeds AutoPlay; the
     * seed track itself comes back first, so callers filter what they have.
     * [preferVideo] takes each song YouTube pairs with its music video as the
     * video — a station played on from a video stays videos.
     */
    suspend fun radio(videoId: String, preferVideo: Boolean = false): Result<List<Song>> =
        call("radio:$videoId:$preferVideo") {
            InnertubeParser.parseWatchQueue(Innertube.next(videoId), preferVideo = preferVideo)
        }

    /**
     * The page of the artist called exactly [name], or null when there is none.
     *
     * YouTube does not link every credited artist. On a real two-artist track
     * the byline and even the album header linked only the first name, so
     * there is no channel behind the second name anywhere in the response. A
     * name is all that is left, and the first search hit for one is not it: ask
     * for `2115` and the results are White 2115, Bedoes 2115, Blacha 2115 and
     * Kuqe 2115, four different people.
     *
     * So a hit is accepted only when its own title is the name asked for. That
     * one rule is the whole of the safety here: `Monday Waxie` finds its page,
     * and `2115` finds nothing and opens nothing rather than somebody else.
     * Asking for `Mate` can land on either of two artists of that name, which
     * is the honest answer to an ambiguous question rather than a wrong one.
     */
    suspend fun findArtistPageId(name: String): Result<String?> = call("artistByName:$name") {
        if (normalizedArtistName(name).isEmpty()) return@call null
        val filter = SearchFilter.ARTISTS
        InnertubeParser.parseSearchPage(Innertube.search(name, filter.params)).rows
            .filterIsInstance<SearchResult.Browse>()
            .map { it.item }
            .firstOrNull { it.type == BrowseType.ARTIST && isExactArtistMatch(it.title, name) }
            ?.browseId
    }

    /**
     * The artist and album pages a track links out to.
     *
     * Search rows carry them, but home cards and anything already sitting in a
     * queue often don't — and the credits in the player have to lead somewhere
     * either way. A track's own watch queue entry always names both.
     */
    suspend fun trackLinks(videoId: String): Result<Song> = call("links:$videoId") {
        InnertubeParser.parseWatchQueue(Innertube.next(videoId))
            .firstOrNull { it.videoId == videoId }
            ?: error("no watch entry for $videoId")
    }

    /**
     * One page of a browse feed's tracks, and the token for the page after
     * it — null once there is nothing more. [suggested] is only ever
     * non-empty for a playlist page — see [InnertubeParser.parsePlaylistShelf].
     */
    data class SongPage(
        val songs: List<Song>,
        val continuation: String?,
        val suggested: List<Song> = emptyList(),
        /**
         * Whether the release this page describes is in the library. Only the
         * first page can answer — a continuation carries rows and nothing else
         * — so it is null from [moreSongs] and must not overwrite what
         * [browseSongs] already established.
         */
        val library: LibraryState? = null,
        /**
         * Whether this page's playlist is one the account made rather than one
         * it saved — see [InnertubeParser.parsePlaylistOwned]. Null for an
         * album, a continuation, or a page that doesn't say.
         */
        val owned: Boolean? = null,
        /**
         * What the page calls itself — only needed by callers that opened it
         * with nothing but a browse id, i.e. a tapped link. Null on a
         * continuation, which carries rows and no header.
         */
        val header: InnertubeParser.BrowseHeader? = null,
        /**
         * The editorial blurb YouTube Music writes for the release, when it
         * has one — see [InnertubeParser.parseDescription]. Null from a
         * continuation, same as [header].
         */
        val description: String? = null,
    )

    /**
     * The first page of an album/playlist's tracks, and nothing more.
     *
     * Deliberately not the whole list. Following every continuation before
     * returning meant a long playlist spent up to ten round trips showing a
     * spinner, when every row needed to fill the first screenful was in the
     * first response. The rest arrives behind a page that is by then already
     * being read — see [moreSongs].
     */
    suspend fun browseSongs(browseId: String): Result<SongPage> = call("browse:$browseId") {
        val response = Innertube.browse(browseId)
        val page = if (browseId.startsWith("MPREb")) {
            albumPageOf(response)
        } else {
            pageOf(response)
        }
        // Only a playlist has an owner in the sense that matters — see
        // parsePlaylistOwned — and only its own first response can be asked.
        if (!browseId.startsWith("VL")) page
        else page.copy(owned = InnertubeParser.parsePlaylistOwned(response))
    }

    /**
     * Joins an album's metadata page to its authoritative track listing.
     *
     * Catalogue album pages sometimes carry only a handful of preview rows.
     * Their header play action names a backing playlist containing every track,
     * so read songs and pagination from there while retaining the richer album
     * header and controls from the original response.
     *
     * Only when that playlist is actually the better listing — see
     * [albumPlaylistOf]. Otherwise the album's own rows stand.
     */
    private suspend fun albumPageOf(albumResponse: JsonObject): SongPage {
        val metadata = pageOf(albumResponse)
        val playlist = albumPlaylistOf(albumResponse, metadata.songs.size) ?: return metadata
        return pageOf(playlist).copy(
            library = metadata.library,
            header = metadata.header,
            description = metadata.description,
        )
    }

    /**
     * The first response of the playlist backing an album, or null when the
     * album page's own rows are the better listing.
     *
     * Not every backing playlist can be browsed. Drake's "Views"
     * (`MPREb_g9nBVaaauTA`) names `OLAK5uy_mmdeq…` in its play button, and
     * browsing that answers 200 with no `contents` at all — only a `noindex`
     * microformat — while the album page itself lists all twenty tracks.
     * Swapping the playlist in unconditionally showed such an album empty.
     *
     * Row counts alone can't decide it, though: an album page stops at 200
     * rows with no continuation, while its playlist pages 100 at a time —
     * `MPREb_pCTElvzIlpy` is 200 rows on the album, 100 + a token on the
     * playlist, and 233 once that is followed. So the album's rows win only
     * when the playlist has fewer *and* nothing more to page.
     */
    private suspend fun albumPlaylistOf(albumResponse: JsonObject, albumRows: Int): JsonObject? {
        val playlistId = InnertubeParser.parseAlbumPlaylistId(albumResponse) ?: return null
        val response = try {
            Innertube.browse("VL${playlistId.removePrefix("VL")}")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "album playlist $playlistId failed, keeping album rows: ${e.message}")
            return null
        }
        val shelf = InnertubeParser.parsePlaylistShelf(response)
        val rows = (shelf?.songs ?: InnertubeParser.collectSongsDeep(response)).size
        val more = (shelf?.continuation ?: InnertubeParser.continuationToken(response)) != null
        if (rows < albumRows && !more) {
            Log.w(TAG, "album playlist $playlistId has $rows rows vs album's $albumRows, keeping album rows")
            return null
        }
        return response
    }

    /** The page [SongPage.continuation] points at. */
    suspend fun moreSongs(token: String): Result<SongPage> = call("browse:more") {
        pageOf(Innertube.browseContinuation(token), showByToken[token])
    }

    /**
     * The podcast each continuation token pages through — see
     * [InnertubeParser.podcastShow].
     *
     * Kept here rather than handed back with the token, because a token goes
     * on to places that know nothing about podcasts — the detail page's
     * fill-in, the playback service's own paging — and each of them only ever
     * calls [moreSongs] with it.
     */
    private val showByToken = ConcurrentHashMap<String, String>()

    /**
     * Whether [browseId] is a playlist the account made — see
     * [InnertubeParser.parsePlaylistOwned].
     *
     * The same question [browseSongs] answers on the way past, asked on its own
     * by whatever needs it without a page open: holding a playlist card offers
     * Rename and Delete, and the card itself cannot say whether either applies.
     * The rows it fetches are thrown away, which is the price of one request for
     * a menu that would otherwise have to guess.
     */
    suspend fun playlistOwned(browseId: String): Result<Boolean?> = call("owner:$browseId") {
        InnertubeParser.parsePlaylistOwned(Innertube.browse(browseId))
    }

    /** [show] is the podcast a continuation [response] pages through, if any — see [showByToken]. */
    private fun pageOf(response: JsonObject, show: String? = null): SongPage {
        val library = InnertubeParser.parseLibraryState(response)
        val header = InnertubeParser.parseBrowseHeader(response)
        // A playlist page is scoped to its own shelf so its "Suggested
        // tracks" never read as songs the user added — see
        // parsePlaylistShelf. Anything else (album, library, history,
        // podcast) has no such shelf, and falls back to the layout-agnostic walk.
        InnertubeParser.parsePlaylistShelf(response)?.let { shelf ->
            return SongPage(shelf.songs, shelf.continuation, shelf.suggested, library, header = header)
        }
        val podcast = InnertubeParser.podcastShow(response) ?: show
        val continuation = InnertubeParser.continuationToken(response)
        if (podcast != null && continuation != null) showByToken[continuation] = podcast
        return SongPage(
            // One response can name the same track twice — an album page that
            // also carries a "you might also like" shelf, say. Collecting into a
            // map used to take care of that; paging by hand means saying so.
            songs = InnertubeParser.collectSongsDeep(response, podcast).distinctBy { it.videoId },
            continuation = continuation,
            library = library,
            header = header,
            description = InnertubeParser.parseDescription(response),
        )
    }

    /**
     * The complete track listing behind an album or playlist browse id.
     *
     * The whole list rather than [browseSongs]' first page, because the callers
     * are the ones that act on all of it at once — "Add to queue" on a card
     * whose page was never opened. Queueing the first hundred rows of a
     * three-hundred-track playlist and calling it the playlist would be a
     * quieter kind of wrong than failing outright.
     *
     * Takes as long as the list is long — see [songsPaged].
     */
    suspend fun allSongs(browseId: String): Result<List<Song>> = call("all:$browseId") {
        songsPaged(browseId).ifEmpty { error("No tracks here") }
    }

    /** Auto needs a complete list, never an apparently successful first page. */
    suspend fun autoSongs(browseId: String): Result<List<Song>> = call("auto:$browseId") {
        val identity = Innertube.listenerGeneration
        val first = browseSongs(browseId).getOrThrow()
        val songs = completePages(
            ContinuationPage(first.songs, first.continuation), MAX_PAGES, Song::videoId,
        ) { token ->
            check(identity == Innertube.listenerGeneration) { "Listener changed during list load" }
            val page = moreSongs(token).getOrThrow()
            ContinuationPage(page.songs, page.continuation)
        }
        check(identity == Innertube.listenerGeneration) { "Listener changed during list load" }
        songs
    }

    suspend fun autoPlaylists(): Result<List<ShelfItem>> = call("auto:playlists") {
        val identity = Innertube.listenerGeneration
        val first = InnertubeParser.parseLibraryItemPage(Innertube.browse(LIBRARY_PLAYLISTS))
        val cards = completePages(
            ContinuationPage(first.items, first.continuation), MAX_PAGES,
            { item: ShelfItem -> item.browseId ?: item.videoId ?: "${item.title}\n${item.subtitle}" },
        ) { token ->
            check(identity == Innertube.listenerGeneration) { "Listener changed during list load" }
            val page = InnertubeParser.parseLibraryItemPage(Innertube.browseContinuation(token))
            ContinuationPage(page.items, page.continuation)
        }
        check(identity == Innertube.listenerGeneration) { "Listener changed during list load" }
        cards
    }

    /**
     * Every track behind a browse id, following continuations.
     *
     * A playlist page returns its first ~100 rows and a token for the rest, so
     * a long list otherwise arrives silently truncated. Capped at
     * [MAX_PAGES] so a runaway feed can't hold the UI open forever, and a
     * failed page keeps whatever was already collected.
     *
     * Holds its caller until the last page lands, so it belongs behind things
     * nobody is watching — the library sync, an artist's back catalogue. For
     * anything a screen is waiting on, use [browseSongs] and [moreSongs].
     */
    private suspend fun songsPaged(browseId: String): List<Song> {
        val out = LinkedHashMap<String, Song>()
        var response = Innertube.browse(browseId)
        if (browseId.startsWith("MPREb")) {
            val albumRows = InnertubeParser.collectSongsDeep(response).size
            albumPlaylistOf(response, albumRows)?.let { response = it }
        }
        var page = 1
        // Named by the first page alone; see [InnertubeParser.podcastShow].
        val show = InnertubeParser.podcastShow(response)
        while (true) {
            // Same shelf-scoping as pageOf: a playlist (Liked Music and the
            // Library Songs auto-playlist included) is read from its own
            // shelf so a trailing "Suggested tracks" shelf never joins in.
            val shelf = InnertubeParser.parsePlaylistShelf(response)
            (shelf?.songs ?: InnertubeParser.collectSongsDeep(response, show)).forEach { out[it.videoId] = it }
            val token = shelf?.continuation ?: InnertubeParser.continuationToken(response)
            if (token == null || page++ >= MAX_PAGES) break
            response = runCatching { Innertube.browseContinuation(token) }.getOrNull() ?: break
        }
        return out.values.toList()
    }

    /**
     * Every saved library card behind a feed browse id, following continuations.
     *
     * The library shelves are capped by YouTube's first page just like search:
     * playlists, albums and artists often stop at about twenty-five rows unless
     * their feed continuation is followed. These are background library loads,
     * so collecting the full bounded set before publishing is preferable to a
     * shelf that looks complete and silently is not.
     */
    private suspend fun itemsPaged(browseId: String, params: String? = null): List<ShelfItem> {
        val out = LinkedHashMap<String, ShelfItem>()
        var response = Innertube.browse(browseId, params)
        var page = 1
        while (true) {
            val parsed = InnertubeParser.parseLibraryItemPage(response)
            parsed.items.forEach { item ->
                val key = item.browseId ?: item.videoId ?: "${item.title}\n${item.subtitle}"
                out.putIfAbsent(key, item)
            }
            val token = parsed.continuation ?: break
            if (page++ >= MAX_PAGES) break
            response = runCatching { Innertube.browseContinuation(token) }.getOrNull() ?: break
        }
        return out.values.toList()
    }

    private suspend fun libraryItemsPaged(browseId: String): List<ShelfItem> = itemsPaged(browseId, null)

    const val MAX_PAGES = 10

    /**
     * Liked Music: the `LM` auto-playlist, addressed as a playlist browse id.
     * Public because it is also the page a track has to disappear from the
     * moment it stops being liked — see MainViewModel's `dropFromLikedLists`.
     */
    const val LIKED_MUSIC = "VLLM"

    /** Songs explicitly added to the library — distinct from Liked Music. */
    private const val LIBRARY_SONGS = "FEmusic_liked_videos"

    /** Saved and own playlists; also what the "add to playlist" picker lists. */
    private const val LIBRARY_PLAYLISTS = "FEmusic_liked_playlists"

    /**
     * What the playlists shelf is called in a [LibraryPage].
     *
     * Coined here, and named here rather than spelt out at each use, because it
     * is the only shelf in the library anything else looks for by name: it is
     * the one the create tile leads (see LibraryScreen) and the one a rename or
     * a delete has to reach into (see MainViewModel's `editPlaylistShelf`).
     * Three copies of a bare "Playlists" is three places a retitling silently
     * turns those features off.
     */
    const val PLAYLISTS_SHELF = "Playlists"

    private val LIBRARY_FEEDS = listOf(
        PLAYLISTS_SHELF to LIBRARY_PLAYLISTS,
        "Albums" to "FEmusic_liked_albums",
        "Artists" to "FEmusic_library_corpus_track_artists",
        "Subscriptions" to "FEmusic_library_corpus_artists",
        "Podcasts" to "FEmusic_library_non_music_audio_list",
    )

    // ---- Writes -------------------------------------------------------------

    /**
     * The account's own state for one track — rating and library membership.
     *
     * Deliberately a lookup rather than something cached with the [Song]: a
     * track reaching the player through the queue has been round-tripped
     * through a MediaItem, which carries an id and little else, and the
     * feedback tokens are per-row anyway. Fetched when a menu is opened, which
     * is the only moment the answer is looked at.
     */
    suspend fun songMenu(videoId: String): Result<SongMenu> = call("menu:$videoId") {
        InnertubeParser.parseSongMenu(Innertube.next(videoId), videoId)
            ?: error("no menu for $videoId")
    }

    suspend fun rate(videoId: String, status: LikeStatus): Result<Unit> =
        call("rate:$videoId") { Innertube.rate(videoId, status) }

    /** Adds or removes a track from the library; [token] says which. */
    suspend fun setLibraryStatus(token: String): Result<Unit> =
        call("library:feedback") { Innertube.sendFeedback(token) }

    /**
     * Saves an album or playlist to the library, or removes it. [playlistId] is
     * the one the page named — see [LibraryState].
     */
    /**
     * Whether the release at [browseId] is in the library, and the playlist that
     * saving it acts on — read off the release's own page, since a card that
     * only knows the browse id has neither. Null where the page offers no save
     * button (a signed-out response, or a release YouTube marks unsaveable).
     */
    suspend fun releaseLibraryState(browseId: String): Result<LibraryState?> =
        call("library-state:$browseId") { InnertubeParser.parseLibraryState(Innertube.browse(browseId)) }

    suspend fun setSaved(playlistId: String, saved: Boolean): Result<Unit> =
        call("library:$playlistId") { Innertube.ratePlaylist(playlistId, saved) }

    /**
     * Subscribes to an artist's channel, or unsubscribes. [channelId] is the one
     * the page's own subscribe button named — see
     * [com.music.bitchord.data.model.SubscriptionState].
     */
    suspend fun setSubscribed(channelId: String, subscribed: Boolean): Result<Unit> =
        call("subscription:$channelId") { Innertube.setSubscribed(channelId, subscribed) }

    /**
     * The playlists a track can be added to. Paged because accounts with long
     * playlist collections otherwise lose everything past YouTube's first
     * library-feed response.
     */
    suspend fun userPlaylists(): Result<List<UserPlaylist>> = call("playlists") {
        InnertubeParser.parseUserPlaylists(libraryItemsPaged(LIBRARY_PLAYLISTS))
    }

    /**
     * All playlists in user library (including Liked Music and saved playlists).
     */
    suspend fun libraryPlaylists(): Result<List<ShelfItem>> = call("libraryPlaylists") {
        InnertubeParser.parseLibraryItems(Innertube.browse(LIBRARY_PLAYLISTS))
    }

    /** Creates a playlist, optionally seeded with [videoIds]; returns its id. */
    suspend fun createPlaylist(
        title: String,
        privacy: PlaylistPrivacy,
        videoIds: List<String> = emptyList(),
    ): Result<String> = call("playlist:create") {
        Innertube.createPlaylist(title, privacy, videoIds = videoIds)
    }

    /**
     * Adds tracks to a playlist. Succeeds with the per-entry ids YouTube minted
     * for them — see [Innertube.addToPlaylist]. A caller with nothing on screen
     * to update can ignore the map; one splicing the row into a playlist it is
     * looking at needs it for the row's "remove".
     */
    suspend fun addToPlaylist(
        playlistId: String,
        videoIds: List<String>,
    ): Result<Map<String, String>> =
        call("playlist:add") { Innertube.addToPlaylist(playlistId, videoIds) }

    /** [entries] are (setVideoId, videoId) pairs — see [Song.setVideoId]. */
    suspend fun removeFromPlaylist(
        playlistId: String,
        entries: List<Pair<String, String>>,
    ): Result<Unit> = call("playlist:remove") {
        Innertube.removeFromPlaylist(playlistId, entries)
    }

    /**
     * A playlist's entries in their current order, every page of them, for
     * rearranging.
     *
     * Fetched fresh rather than read off the open page, because a reorder is
     * sent as moves relative to neighbours (see [playlistMoves]) and a list
     * that stops short of the end — the open page while it is still filling
     * in — would send the last row it has "to the end" past rows it never saw.
     * Fails when an entry comes back without the set-video-id a move has to
     * name, rather than offering to reorder something it can't.
     */
    suspend fun playlistEntries(browseId: String): Result<List<Song>> = call("entries:$browseId") {
        val out = LinkedHashMap<String, Song>()
        var response = Innertube.browse(browseId)
        var page = 1
        while (true) {
            val shelf = InnertubeParser.parsePlaylistShelf(response) ?: break
            shelf.songs.forEach { song ->
                val setVideoId = song.setVideoId ?: error("playlist entry without an id")
                out.putIfAbsent(setVideoId, song)
            }
            val token = shelf.continuation ?: break
            // Same cap as [songsPaged] — a playlist past it can't be listed
            // whole, and a partial list can't be reordered safely.
            if (page++ >= MAX_PAGES) error("playlist too long to reorder")
            response = Innertube.browseContinuation(token)
        }
        out.values.toList()
    }

    /**
     * Rearranges a playlist from [current] to [target], both its entries'
     * set-video-ids — see [playlistMoves]. Sent in batches so a large
     * rearrangement doesn't become one oversized request.
     */
    suspend fun reorderPlaylist(
        playlistId: String,
        current: List<String>,
        target: List<String>,
    ): Result<Unit> = call("playlist:reorder") {
        playlistMoves(current, target).chunked(MOVE_BATCH).forEach { batch ->
            Innertube.movePlaylistItems(playlistId, batch)
        }
    }

    private const val MOVE_BATCH = 50

    suspend fun renamePlaylist(playlistId: String, title: String): Result<Unit> =
        call("playlist:rename") { Innertube.renamePlaylist(playlistId, title) }

    suspend fun deletePlaylist(playlistId: String): Result<Unit> =
        call("playlist:delete") { Innertube.deletePlaylist(playlistId) }

    /**
     * Artist page. The landing page only lists ~5 songs, so the linked
     * "Top songs" playlist is fetched to fill the list out, and any linked
     * full release shelves (Albums, Singles & EPs) are fetched to populate
     * their complete discography.
     */
    suspend fun artistPage(browseId: String): Result<ArtistPage> = call("artist:$browseId") {
        val page = InnertubeParser.parseArtistPage(Innertube.browse(browseId))
        coroutineScope {
            val fullSongsDeferred = async {
                page.moreSongsBrowseId?.let { playlistId ->
                    runCatching { songsPaged(playlistId) }.getOrNull()
                }
            }
            val shelvesDeferred = page.sections.map { shelf ->
                async {
                    val moreBrowseId = shelf.moreBrowseId
                    if (moreBrowseId != null) {
                        val fullItems = runCatching {
                            itemsPaged(moreBrowseId, shelf.moreParams)
                        }.getOrNull()
                        if (!fullItems.isNullOrEmpty()) {
                            shelf.copy(items = fullItems)
                        } else {
                            shelf
                        }
                    } else {
                        shelf
                    }
                }
            }
            val fullSongs = fullSongsDeferred.await()
            val fullShelves = shelvesDeferred.awaitAll()
            val resolvedSongs = if (!fullSongs.isNullOrEmpty()) fullSongs else page.songs
            page.copy(songs = resolvedSongs, sections = fullShelves)
        }
    }

    /**
     * The artist's landing page alone — one request. [artistPage] goes on to
     * page out every song and release, which a Top Picks card has no use for:
     * it needs the header (photo, Mix and Shuffle) and the first card of each
     * shelf.
     */
    suspend fun artistLanding(browseId: String): Result<ArtistPage> = call("artistLanding:$browseId") {
        InnertubeParser.parseArtistPage(Innertube.browse(browseId))
    }

    /**
     * The queue a watch target starts — a mix, a playlist radio, or an artist's
     * Mix or Shuffle button. Music videos are dropped, as everywhere a queue is
     * built for the listener rather than picked by them.
     */
    suspend fun watchQueue(target: WatchTarget): Result<List<Song>> = call("watch:${target.playlistId}") {
        InnertubeParser.parseWatchQueue(
            Innertube.nextPlaylist(target.playlistId, target.videoId, target.params),
        ).filterNot { it.isVideo }
    }

    /**
     * A playlist's tracks as a watch queue, each one as audio where YouTube
     * can say what the audio version is. Editorial playlists list mostly
     * official videos; signed in, `next` pairs each with the song it's a
     * video of, so the song is taken directly instead of being searched for
     * when it comes to play. A row with no pair stays the video — the player's
     * own video-to-audio step still covers it.
     */
    suspend fun playlistAsAudio(playlistId: String): Result<List<Song>> = call("watchAudio:$playlistId") {
        val response = Innertube.nextPlaylist(playlistId)
        val songs = InnertubeParser.parseWatchQueue(response, preferAudio = true)
        val (pairs, audioPairs) = InnertubeParser.watchQueuePairs(response)
        Log.d(TAG, "watchAudio $playlistId rows=${songs.size} pairs=$pairs audioPairs=$audioPairs videosLeft=${songs.count { it.isVideo }}")
        songs
    }

    /**
     * The cards of the signed-in "Mixed for you" page — My Supermix, Discover
     * Mix, New Release Mix and the numbered My Mixes. Home carries the same
     * cards as a shelf, but not always on its first page; this is the page
     * that shelf's More opens, and it answers in one request.
     */
    suspend fun mixedForYou(): Result<List<ShelfItem>> = call("mixedForYou") {
        if (Innertube.cookie == null) return@call emptyList()
        InnertubeParser.parseTwoRowItemsDeep(Innertube.browse("FEmusic_mixed_for_you"))
    }

    /**
     * Listening history for a caller that can live with it being a minute or
     * two old — Top Picks, built right after Recents fetched the same feed.
     * Every real fetch refreshes the memo, so nothing reading [history] or
     * [recentlyPlayed] ever sees a stale copy.
     */
    suspend fun recentHistory(): Result<List<Song>> = call("history:recent") {
        if (Innertube.cookie == null) return@call emptyList()
        val memo = historyMemo
        if (memo != null && memo.identity == Innertube.listenerGeneration &&
            System.currentTimeMillis() - memo.at < HISTORY_MEMO_MS
        ) {
            memo.songs
        } else {
            fetchHistory()
        }
    }

    private class HistoryMemo(val identity: Long, val at: Long, val songs: List<Song>)

    @Volatile
    private var historyMemo: HistoryMemo? = null

    private const val HISTORY_MEMO_MS = 120_000L

    private suspend fun <T> call(label: String, block: suspend () -> T): Result<T> {
        val generation = currentCoroutineContext()[Innertube.ListenerContext]?.generation
            ?: Innertube.listenerGeneration
        return withContext(Dispatchers.IO + Innertube.ListenerContext(generation)) {
            runCatching {
                check(generation == Innertube.listenerGeneration) { "Listener changed before $label" }
                block().also {
                    check(generation == Innertube.listenerGeneration) { "Listener changed during $label" }
                }
            }.recoverCatching { failure ->
                if (failure is CancellationException) throw failure
                if (generation != Innertube.listenerGeneration) throw failure
                // Context cookies can rotate while a process is alive. Refresh
                // once and retry; never loop or silently sign the listener out.
                val rejected = failure.message?.contains("401") == true ||
                    failure.message?.contains("403") == true ||
                    failure.message?.contains("rejected", true) == true
                if (!rejected || Innertube.cookie == null) throw failure
                Log.w(TAG, "$label rejected; refreshing active session context once")
                Innertube.refreshSessionScope()
                check(generation == Innertube.listenerGeneration) { "Listener changed before retrying $label" }
                block().also {
                    check(generation == Innertube.listenerGeneration) { "Listener changed during retry of $label" }
                }
            }
                // runCatching catches Throwable, cancellation included, which
                // would turn "the user typed another letter" into a failed
                // Result and put the abandoned request's error on screen.
                // Cancellation isn't this call's to answer for.
                .onFailure { if (it is CancellationException) throw it }
                .onSuccess { Log.d(TAG, "$label ok") }
                .onFailure { Log.w(TAG, "$label failed: ${it.message}") }
        }
    }
}
