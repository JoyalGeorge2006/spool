package com.music.bitchord.data.settings

import org.junit.Test
import org.junit.Assert.*

class BackupPreferenceTypesTest {
    @Test fun validatesFreshInstallKeysRatherThanTrustingFileTypes() {
        try { BackupPreferenceTypes.checked(mapOf("spool_updates_auto" to "bad"), emptyMap<String, Any>()); fail("must reject") }
        catch (_: IllegalArgumentException) { }
    }
    @Test fun acceptsTypedKnownAndExistingSettings() {
        val values = mapOf("spool_updates_auto" to false, "fixture" to "a")
        assertEquals(values, BackupPreferenceTypes.checked(values, mapOf("fixture" to "b")))
    }
    @Test fun unknownAbsentKeysAreNotInstalled() {
        assertTrue(BackupPreferenceTypes.checked(mapOf("future-key" to "x"), emptyMap<String, Any>()).isEmpty())
    }
    @Test fun nonFiniteFloatRejected() {
        try { BackupPreferenceTypes.checked(mapOf("fixture" to Float.NaN), mapOf("fixture" to 1f)); fail("must reject") }
        catch (_: IllegalArgumentException) { }
    }
    @Test fun allWrongPrimitiveTypesAreRejected() {
        for (value in listOf<Any>(1, 1L, 1f, "true", setOf("true"))) {
            try { BackupPreferenceTypes.checked(mapOf("spool_updates_auto" to value), emptyMap<String, Any>()); fail("must reject $value") }
            catch (_: IllegalArgumentException) { }
        }
    }
}
